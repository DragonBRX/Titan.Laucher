# 🐧 TITAN LAUNCHER v2.6.1 ULTIMATE - LINUX EDITION

## ⚡ Instalação com 1 Comando

```bash
chmod +x instalar.sh && ./instalar.sh
```

**Pronto!** O script faz tudo automaticamente.

---

## 🚀 O Que é Novo

### ✨ Expansão Massiva
- **10 Temas Profissionais** - Personalize o visual
- **Gerenciador de Shaders** - Instale shaders facilmente
- **Sistema de Notificações** - Feedback visual elegante
- **Monitor de Performance** - CPU e RAM em tempo real
- **Exportar/Importar Perfis** - Compartilhe configurações
- **Backup Automático** - Nunca perca seus dados

### 🐧 Otimizado para Linux
- ✅ Compatível com X11 e Wayland
- ✅ Detecta automaticamente sua distribuição
- ✅ Instala dependências corretas
- ✅ Sem código Windows
- ✅ 100% nativo

---

## 📋 Distribuições Suportadas

- ✅ **Arch Linux** / Manjaro
- ✅ **Ubuntu** / Mint / Pop!_OS
- ✅ **Debian**
- ✅ **Fedora** / RHEL / CentOS
- ✅ **openSUSE**
- ✅ Outras (com Python 3.8+)

---

## 🎯 Uso Rápido

### Primeira Vez

```bash
# 1. Executar instalador
./instalar.sh

# 2. Criar perfil
# - Clique "+ Novo Perfil"
# - Preencha nome, versão, RAM
# - Salvar

# 3. Instalar Minecraft
# - Clique "Instalar"
# - Aguarde download

# 4. Jogar!
# - Clique "Jogar"
```

### Próximas Vezes

```bash
cd TitanLauncher
./titan-launcher.sh
```

**OU:**

```bash
cd TitanLauncher
python3 src/main.py
```

---

## 🎨 Recursos Principais

### Sistema de Temas
10 temas incluídos:
- Dark (padrão)
- Light
- Nord
- Dracula
- Monokai
- Ocean
- Gruvbox
- Solarized
- Cyberpunk
- Creeper

**Trocar tema:** Menu → Configurações → Tema

### Gerenciador de Shaders
- Drag & drop para instalar
- 10+ shaders populares
- Habilitar/Desabilitar com 1 clique
- Recomendações por versão
- Detecção de OptiFine/Iris

### Monitor de Performance
- CPU e RAM em tempo real
- Janela completa de detalhes
- Widget compacto
- Zero impacto

### Exportar/Importar
- Formato .titanprofile
- Inclui mods, saves, configs
- Compartilhe com amigos
- Preview antes de importar

---

## 🔧 Dependências

Instaladas automaticamente pelo script:

- **Python 3.8+**
- **minecraft-launcher-lib** - Gerenciamento do Minecraft
- **Pillow** - Manipulação de imagens
- **psutil** - Monitor de sistema (opcional)
- **tkinter** - Interface gráfica

---

## 📁 Estrutura

```
~/.config/titanlauncher/
├── minecraft/              # Instalações do Minecraft
│   ├── Perfil1/
│   ├── Perfil2/
│   └── ...
├── profiles.json           # Seus perfis
├── launcher_config.json    # Configurações básicas
├── advanced_config.json    # Config avançada v2.6
└── backups/               # Backups automáticos
```

---

## 🐛 Solução de Problemas

### Python não encontrado
```bash
# Arch
sudo pacman -S python python-pip

# Ubuntu/Debian
sudo apt install python3 python3-pip

# Fedora
sudo dnf install python3 python3-pip
```

### Tkinter não encontrado
```bash
# Arch
sudo pacman -S tk

# Ubuntu/Debian
sudo apt install python3-tk

# Fedora
sudo dnf install python3-tkinter
```

### Java não encontrado
```bash
# Arch
sudo pacman -S jre-openjdk

# Ubuntu/Debian
sudo apt install openjdk-17-jre

# Fedora
sudo dnf install java-17-openjdk
```

### Dependências não instalam
```bash
# Tentar manualmente
cd TitanLauncher
pip3 install --user --break-system-packages -r requirements.txt

# Se ainda falhar
python3 -m pip install --user minecraft-launcher-lib pillow psutil
```

---

## ⌨️ Atalhos

- `Ctrl+N` - Novo Perfil
- `Ctrl+P` - Jogar Último Perfil
- `Ctrl+B` - Criar Backup
- `Ctrl+,` - Configurações
- `F5` - Atualizar
- `Ctrl+T` - Trocar Tema
- `Ctrl+M` - Monitor de Performance
- `Ctrl+Q` - Sair

---

## 🌈 Shaders Recomendados

### Leves (60+ FPS)
- BSL Shaders
- MakeUp Ultra Fast
- Vanilla Plus

### Médios (30-60 FPS)
- Complementary
- Sildur's Vibrant
- ProjectLUMA

### Pesados (GPU potente)
- SEUS PTGI
- Continuum

---

## 💡 Dicas

### Performance Máxima
```
RAM: 6-8GB
Shaders: Leves
Optimization: High
```

### Visual Máximo
```
Shaders: SEUS PTGI
RAM: 8GB+
OptiFine: Ativado
```

### Economizar Espaço
- Compartilhe pasta de mods entre perfis
- Delete versões antigas
- Use backup em nuvem

---

## 📊 Estatísticas

- **Código:** ~8000+ linhas
- **Módulos:** 7
- **Temas:** 10
- **Shaders:** 10+
- **Plataforma:** Linux (X11/Wayland)
- **Python:** 3.8 - 3.14+

---

## 🔍 Verificar Instalação

```bash
# Ver módulos carregados
python3 src/main.py 2>&1 | grep "carregado"

# Verificar dependências
pip3 list | grep -E "minecraft|Pillow|psutil"

# Testar tkinter
python3 -c "import tkinter; print('OK')"
```

---

## 📝 Arquivos do Projeto

```
titan_v2_6_LINUX/
├── instalar.sh                  # Instalador automático
├── README.md                    # Este arquivo
│
└── TitanLauncher/
    ├── titan-launcher.sh        # Executável rápido
    ├── requirements.txt         # Dependências Python
    │
    ├── src/                     # Código fonte
    │   ├── main.py              # Principal
    │   ├── themes.py            # Temas
    │   ├── notifications.py     # Notificações
    │   ├── performance.py       # Monitor
    │   ├── shader_manager.py    # Shaders
    │   ├── profile_manager.py   # Export/Import
    │   └── utils.py             # Utilitários
    │
    ├── assets/                  # Recursos visuais
    │   ├── icons/
    │   └── avatars/
    │
    └── config/                  # Configurações
```

---

## ✅ Checklist Antes de Jogar

- [ ] Python 3.8+ instalado
- [ ] Dependências instaladas
- [ ] Java 17+ instalado
- [ ] Perfil criado
- [ ] Minecraft instalado no perfil
- [ ] RAM configurada (4-8GB)
- [ ] Tema escolhido (opcional)

---

## 🚀 Começar Agora

```bash
# 1. Dar permissão
chmod +x instalar.sh

# 2. Executar
./instalar.sh

# 3. Criar perfil e jogar!
```

---

## 📞 Suporte

### Problemas?
1. Veja "Solução de Problemas" acima
2. Verifique os logs: `python3 src/main.py 2>&1 | tee log.txt`
3. Certifique-se que tem Java instalado

### Logs Detalhados
```bash
cd TitanLauncher
python3 src/main.py 2>&1 | tee ~/titan-launcher.log
```

---

## 🎉 Aproveite!

**Titan Launcher v2.6.1 ULTIMATE**  
*A versão mais completa para Linux!*

**100% focado em Linux**  
*Sem código Windows, totalmente nativo*

---

**Feito com ❤️ para a comunidade Minecraft no Linux** 🐧
