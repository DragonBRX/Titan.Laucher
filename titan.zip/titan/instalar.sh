#!/bin/bash
#=====================================================
# TITAN LAUNCHER v2.6.1 ULTIMATE - LINUX EDITION
# Script de Instalação, Compilação e Execução Automática
#=====================================================

set -e

# Cores
RED='\\033[0;31m'
GREEN='\\033[0;32m'
YELLOW='\\033[1;33m'
BLUE='\\033[0;34m'
CYAN='\\033[0;36m'
NC='\\033[0m' # Sem cor

# Configurações
APP_NAME="TitanLauncher"
BINARY_NAME="titan-launcher"
DESKTOP_FILE="titan-launcher.desktop"
ICON_NAME="titan-launcher.png"
INSTALL_DIR="$HOME/.local/share/$APP_NAME"
BIN_DIR="$HOME/.local/bin"
DESKTOP_DIR="$HOME/.local/share/applications"
ICON_DIR="$HOME/.local/share/icons/hicolor/256x256/apps"

# Banner
echo -e "${BLUE}"
cat << "EOF"
╔════════════════════════════════════════════════════╗
║      TITAN LAUNCHER v2.6.1 ULTIMATE                ║
║           LINUX EDITION                            ║
╚════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"

# Função de log
log_info() {
    echo -e "${GREEN}✓${NC} $1"
}

log_error() {
    echo -e "${RED}✗${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}⚠${NC} $1"
}

log_step() {
    echo -e "${CYAN}→${NC} $1"
}

# Detectar distribuição
detect_distro() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        DISTRO=$ID
    else
        DISTRO="unknown"
    fi
}

# Verificar e remover versões antigas (Alchem, Titan antigo, etc.)
remove_old_versions() {
    log_step "Verificando versões anteriores..."

    local found_old=false

    # Verificar instalações antigas do Titan Launcher
    if [ -d "$HOME/.local/share/TitanLauncher" ] && [ "$INSTALL_DIR" != "$HOME/.local/share/TitanLauncher" ]; then
        log_warn "Removendo instalação antiga do Titan Launcher..."
        rm -rf "$HOME/.local/share/TitanLauncher"
        found_old=true
    fi

    # Verificar binários antigos
    local old_binaries=("titan-launcher" "titanlauncher" "TitanLauncher" "alchem-launcher" "alchem" "AlchemLauncher")
    for binary in "${old_binaries[@]}"; do
        if [ -f "$BIN_DIR/$binary" ]; then
            log_warn "Removendo binário antigo: $binary"
            rm -f "$BIN_DIR/$binary"
            found_old=true
        fi
        if [ -f "/usr/local/bin/$binary" ]; then
            log_warn "Removendo binário antigo do sistema: $binary"
            sudo rm -f "/usr/local/bin/$binary" 2>/dev/null || true
        fi
    done

    # Verificar arquivos .desktop antigos
    local old_desktops=("titan-launcher.desktop" "titanlauncher.desktop" "alchem-launcher.desktop" "alchem.desktop")
    for desktop in "${old_desktops[@]}"; do
        if [ -f "$DESKTOP_DIR/$desktop" ]; then
            log_warn "Removendo entrada de menu antiga: $desktop"
            rm -f "$DESKTOP_DIR/$desktop"
            found_old=true
        fi
        if [ -f "$HOME/.config/autostart/$desktop" ]; then
            rm -f "$HOME/.config/autostart/$desktop"
        fi
    done

    # Verificar diretórios de versões antigas (Alchem, etc.)
    local old_dirs=("$HOME/.local/share/alchem" "$HOME/.local/share/AlchemLauncher" "$HOME/.alchem" "$HOME/.titan-old")
    for dir in "${old_dirs[@]}"; do
        if [ -d "$dir" ]; then
            log_warn "Removendo diretório antigo: $dir"
            rm -rf "$dir"
            found_old=true
        fi
    done

    # Atualizar banco de dados de aplicativos
    if command -v update-desktop-database &> /dev/null; then
        update-desktop-database "$DESKTOP_DIR" 2>/dev/null || true
    fi

    if [ "$found_old" = true ]; then
        log_info "Versões antigas removidas com sucesso"
    else
        log_info "Nenhuma versão anterior encontrada"
    fi

    sleep 1
}

# Instalar Python e dependências do sistema
install_system_deps() {
    log_info "Detectando distribuição Linux..."
    detect_distro

    case $DISTRO in
        arch|manjaro)
            log_info "Distribuição Arch detectada"
            if ! command -v python3 &> /dev/null; then
                log_warn "Python3 não encontrado. Instalando..."
                sudo pacman -S --needed python python-pip tk
            fi
            # Instalar dependências de compilação
            if ! command -v gcc &> /dev/null; then
                log_warn "Instalando ferramentas de compilação..."
                sudo pacman -S --needed base-devel python-pip
            fi
            ;;
        ubuntu|debian|mint|pop)
            log_info "Distribuição Debian/Ubuntu detectada"
            if ! command -v python3 &> /dev/null; then
                log_warn "Python3 não encontrado. Instalando..."
                sudo apt update
                sudo apt install -y python3 python3-pip python3-tk python3-venv
            fi
            # Instalar dependências de compilação
            if ! command -v gcc &> /dev/null; then
                log_warn "Instalando ferramentas de compilação..."
                sudo apt install -y build-essential python3-dev
            fi
            ;;
        fedora|rhel|centos)
            log_info "Distribuição Fedora/RHEL detectada"
            if ! command -v python3 &> /dev/null; then
                log_warn "Python3 não encontrado. Instalando..."
                sudo dnf install -y python3 python3-pip python3-tkinter
            fi
            # Instalar dependências de compilação
            if ! command -v gcc &> /dev/null; then
                log_warn "Instalando ferramentas de compilação..."
                sudo dnf install -y gcc python3-devel
            fi
            ;;
        opensuse*)
            log_info "Distribuição openSUSE detectada"
            if ! command -v python3 &> /dev/null; then
                log_warn "Python3 não encontrado. Instalando..."
                sudo zypper install -y python3 python3-pip python3-tk
            fi
            # Instalar dependências de compilação
            if ! command -v gcc &> /dev/null; then
                log_warn "Instalando ferramentas de compilação..."
                sudo zypper install -y gcc python3-devel
            fi
            ;;
        *)
            log_warn "Distribuição desconhecida: $DISTRO"
            log_warn "Certifique-se de ter Python 3.8+, pip, gcc e python3-dev instalados"
            ;;
    esac
}

# Verificar Python
check_python() {
    log_info "Verificando Python..."

    if ! command -v python3 &> /dev/null; then
        log_error "Python3 não encontrado!"
        log_info "Tentando instalar..."
        install_system_deps
    fi

    PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
    log_info "Python encontrado: $PYTHON_VERSION"

    # Verificar versão mínima (3.8)
    PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
    PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)

    if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 8 ]); then
        log_error "Python 3.8+ é necessário!"
        exit 1
    fi
}

# Verificar pip
check_pip() {
    log_info "Verificando pip..."

    if ! command -v pip3 &> /dev/null && ! command -v pip &> /dev/null; then
        log_error "pip não encontrado!"
        log_info "Instalando pip..."

        case $DISTRO in
            arch|manjaro)
                sudo pacman -S --needed python-pip
                ;;
            ubuntu|debian|mint|pop)
                sudo apt install -y python3-pip
                ;;
            fedora|rhel|centos)
                sudo dnf install -y python3-pip
                ;;
            *)
                log_warn "Instale o pip manualmente"
                exit 1
                ;;
        esac
    fi

    log_info "pip encontrado"
}

# Verificar tkinter
check_tkinter() {
    log_info "Verificando tkinter..."

    if ! python3 -c "import tkinter" 2>/dev/null; then
        log_warn "tkinter não encontrado! Instalando..."

        case $DISTRO in
            arch|manjaro)
                sudo pacman -S --needed tk
                ;;
            ubuntu|debian|mint|pop)
                sudo apt install -y python3-tk
                ;;
            fedora|rhel|centos)
                sudo dnf install -y python3-tkinter
                ;;
            opensuse*)
                sudo zypper install -y python3-tk
                ;;
            *)
                log_error "Instale tkinter manualmente para sua distribuição"
                exit 1
                ;;
        esac
    fi

    log_info "tkinter disponível"
}

# Instalar dependências Python necessárias para compilação
install_python_deps() {
    log_info "Instalando dependências Python para compilação..."

    # Criar ambiente virtual temporário para compilação
    if [ -d "build_env" ]; then
        rm -rf build_env
    fi

    python3 -m venv build_env
    source build_env/bin/activate

    # Atualizar pip
    pip install --upgrade pip

    # Instalar dependências do projeto
    if [ -f "TitanLauncher/requirements.txt" ]; then
        log_info "Instalando dependências do projeto..."
        pip install -r TitanLauncher/requirements.txt
    fi

    # Instalar PyInstaller e dependências de compilação
    log_info "Instalando PyInstaller e ferramentas de compilação..."
    pip install pyinstaller pillow

    log_info "Dependências instaladas"
}

# Compilar o aplicativo
compile_app() {
    log_step "Compilando Titan Launcher..."

    # Verificar se existe o diretório src
    if [ ! -d "TitanLauncher/src" ]; then
        log_error "Diretório 'TitanLauncher/src' não encontrado!"
        log_warn "Certifique-se de que a estrutura do projeto está correta."
        exit 1
    fi

    # Encontrar o arquivo principal (main.py ou app.py)
    local main_file=""
    if [ -f "TitanLauncher/src/main.py" ]; then
        main_file="src/main.py"
    elif [ -f "TitanLauncher/src/app.py" ]; then
        main_file="src/app.py"
    else
        log_error "Arquivo principal não encontrado em TitanLauncher/src/"
        log_warn "Procurando por main.py ou app.py..."
        exit 1
    fi

    cd TitanLauncher

    # Criar arquivo spec temporário otimizado
    local spec_content="
# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

a = Analysis(
    ['$main_file'],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=['PIL._tkinter_finder', 'minecraft_launcher_lib', 'psutil'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='$BINARY_NAME',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
"

    echo "$spec_content" > titan_build.spec

    # Compilar com PyInstaller
    log_info "Executando PyInstaller (isso pode levar alguns minutos)..."
    pyinstaller --clean --onefile --windowed --name "$BINARY_NAME" --add-data "src:src" "$main_file" 2>&1 | while read line; do
        echo "    $line"
    done

    if [ ! -f "dist/$BINARY_NAME" ]; then
        log_error "Falha na compilação! O executável não foi gerado."
        cd ..
        exit 1
    fi

    log_info "Compilação concluída!"
    cd ..
}

# Instalar o aplicativo compilado
install_app() {
    log_step "Instalando Titan Launcher..."

    # Criar diretórios necessários
    mkdir -p "$INSTALL_DIR"
    mkdir -p "$BIN_DIR"
    mkdir -p "$DESKTOP_DIR"
    mkdir -p "$ICON_DIR"

    # Copiar executável
    cp "TitanLauncher/dist/$BINARY_NAME" "$INSTALL_DIR/"
    chmod +x "$INSTALL_DIR/$BINARY_NAME"

    # Criar link simbólico em ~/.local/bin
    if [ -L "$BIN_DIR/$BINARY_NAME" ]; then
        rm "$BIN_DIR/$BINARY_NAME"
    fi
    ln -s "$INSTALL_DIR/$BINARY_NAME" "$BIN_DIR/$BINARY_NAME"

    # Copiar recursos (assets, configurações, etc.)
    if [ -d "TitanLauncher/assets" ]; then
        cp -r TitanLauncher/assets "$INSTALL_DIR/"
    fi

    if [ -d "TitanLauncher/config" ]; then
        cp -r TitanLauncher/config "$INSTALL_DIR/"
    fi

    # Criar ícone padrão se não existir
    if [ -f "TitanLauncher/assets/icon.png" ]; then
        cp "TitanLauncher/assets/icon.png" "$ICON_DIR/$ICON_NAME"
    elif [ -f "TitanLauncher/icon.png" ]; then
        cp "TitanLauncher/icon.png" "$ICON_DIR/$ICON_NAME"
    else
        # Criar um ícone simples usando ImageMagick ou copiar um padrão
        log_warn "Ícone não encontrado, criando ícone padrão..."
        # Aqui você pode adicionar lógica para criar um ícone padrão
        touch "$ICON_DIR/$ICON_NAME"
    fi

    # Criar arquivo .desktop
    local desktop_content="[Desktop Entry]\nName=Titan Launcher\nComment=Minecraft Launcher Ultimate Edition\nExec=$INSTALL_DIR/$BINARY_NAME\nIcon=$ICON_DIR/$ICON_NAME\nType=Application\nCategories=Game;\nTerminal=false\nStartupNotify=true\nVersion=2.6.1"

    echo -e "$desktop_content" > "$DESKTOP_DIR/$DESKTOP_FILE"
    chmod +x "$DESKTOP_DIR/$DESKTOP_FILE"

    # Atualizar banco de dados de aplicativos
    if command -v update-desktop-database &> /dev/null; then
        update-desktop-database "$DESKTOP_DIR" 2>/dev/null || true
    fi

    # Adicionar à PATH se necessário
    if [[ ":$PATH:" != *":$BIN_DIR:"* ]]; then
        log_warn "Adicionando $BIN_DIR à sua PATH..."
        echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
        export PATH="$HOME/.local/bin:$PATH"
    fi

    log_info "Instalação concluída!"
}

# Verificar instalação
verify_installation() {
    log_info "Verificando instalação..."

    if [ -f "$INSTALL_DIR/$BINARY_NAME" ]; then
        log_info "Executável instalado: OK"
    else
        log_error "Executável não encontrado!"
        return 1
    fi

    if [ -L "$BIN_DIR/$BINARY_NAME" ]; then
        log_info "Link em ~/.local/bin: OK"
    else
        log_warn "Link em ~/.local/bin não criado"
    fi

    if [ -f "$DESKTOP_DIR/$DESKTOP_FILE" ]; then
        log_info "Entrada de menu: OK"
    else
        log_warn "Entrada de menu não criada"
    fi

    # Testar execução
    if command -v "$BINARY_NAME" &> /dev/null; then
        log_info "Comando disponível: $BINARY_NAME"
    else
        log_warn "Comando não disponível globalmente (reinicie o terminal)"
    fi

    return 0
}

# Executar launcher
run_launcher() {
    log_info "Iniciando Titan Launcher..."
    echo ""

    if command -v "$BINARY_NAME" &> /dev/null; then
        "$BINARY_NAME" &
    else
        "$INSTALL_DIR/$BINARY_NAME" &
    fi

    local PID=$!
    sleep 2

    if ps -p $PID > /dev/null 2>&1; then
        log_info "Titan Launcher iniciado com sucesso! (PID: $PID)"
    else
        log_error "Falha ao iniciar o Titan Launcher"
        wait $PID
        local EXITCODE=$?
        log_error "Código de erro: $EXITCODE"
    fi
}

# Função de desinstalação
uninstall() {
    log_step "Desinstalando Titan Launcher..."

    # Remover diretório de instalação
    if [ -d "$INSTALL_DIR" ]; then
        rm -rf "$INSTALL_DIR"
        log_info "Diretório de instalação removido"
    fi

    # Remover link simbólico
    if [ -L "$BIN_DIR/$BINARY_NAME" ]; then
        rm "$BIN_DIR/$BINARY_NAME"
        log_info "Link removido"
    fi

    # Remover arquivo desktop
    if [ -f "$DESKTOP_DIR/$DESKTOP_FILE" ]; then
        rm "$DESKTOP_DIR/$DESKTOP_FILE"
        log_info "Entrada de menu removida"
    fi

    # Remover ícone
    if [ -f "$ICON_DIR/$ICON_NAME" ]; then
        rm "$ICON_DIR/$ICON_NAME"
    fi

    # Atualizar banco de dados
    if command -v update-desktop-database &> /dev/null; then
        update-desktop-database "$DESKTOP_DIR" 2>/dev/null || true
    fi

    log_info "Desinstalação concluída!"
}

# Menu principal
main() {
    echo ""

    # Verificar argumentos
    if [ "$1" = "--uninstall" ] || [ "$1" = "-u" ]; then
        uninstall
        exit 0
    fi

    if [ "$1" = "--reinstall" ] || [ "$1" = "-r" ]; then
        uninstall
    fi

    log_info "Iniciando instalação automática v2.6.1..."
    echo ""

    # 1. Remover versões antigas (incluindo Alchem, etc.)
    remove_old_versions

    # 2. Detectar distro
    detect_distro

    # 3. Verificar Python
    check_python

    # 4. Verificar pip
    check_pip

    # 5. Verificar tkinter
    check_tkinter

    # 6. Instalar dependências de compilação
    install_python_deps

    # 7. Compilar o aplicativo
    compile_app

    # 8. Instalar o aplicativo compilado
    install_app

    # 9. Verificar instalação
    if verify_installation; then
        echo ""
        log_info "✓ Titan Launcher v2.6.1 instalado com sucesso!"
        log_info "  → Executável: $INSTALL_DIR/$BINARY_NAME"
        log_info "  → Comando: $BINARY_NAME"
        log_info "  → Menu: Aplicativos > Jogos > Titan Launcher"
        echo ""

        # Perguntar se deseja executar
        read -p "Deseja executar o Titan Launcher agora? [S/n]: " response
        response=${response:-S}

        if [[ "$response" =~ ^[Ss]$ ]]; then
            run_launcher
        else
            log_info "Instalação concluída! Execute '$BINARY_NAME' para iniciar."
        fi
    else
        log_error "Falha na verificação da instalação!"
        exit 1
    fi

    # Limpar arquivos temporários
    if [ -d "build_env" ]; then
        rm -rf build_env
    fi
    if [ -d "TitanLauncher/build" ]; then
        rm -rf TitanLauncher/build
    fi
    if [ -d "TitanLauncher/dist" ]; then
        rm -rf TitanLauncher/dist
    fi
    if [ -f "TitanLauncher/titan_build.spec" ]; then
        rm TitanLauncher/titan_build.spec
    fi
}

# Executar
main "$@"
'''

# Salvar o arquivo
with open('/mnt/kimi/output/install_titan.sh', 'w') as f:
    f.write(script_content)

print("Script atualizado criado com sucesso!")
print("\nPrincipais mudanças:")
print("1. ✓ Compilação com PyInstaller para criar executável standalone")
print("2. ✓ Detecção e remoção automática de versões antigas (Alchem, Titan antigo, etc.)")
print("3. ✓ Instalação em ~/.local/share/TitanLauncher")
print("4. ✓ Link em ~/.local/bin para comando global")
print("5. ✓ Entrada no menu de aplicativos (.desktop)")
print("6. ✓ Suporte a argumentos: --uninstall (-u) e --reinstall (-r)")
print("7. ✓ Estrutura original do projeto preservada")
