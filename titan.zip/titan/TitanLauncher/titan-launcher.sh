#!/bin/bash
# TITAN LAUNCHER v2.6.1 - Script de Execução Linux

cd "$(dirname "$0")"
python3 src/main.py
