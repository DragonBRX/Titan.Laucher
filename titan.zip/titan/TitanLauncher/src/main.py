#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TITAN LAUNCHER - Interface Principal
Versão: 2.6.1 ULTIMATE - EXPANDIDO COM RECURSOS AVANÇADOS
Download e instalação real do Minecraft com recursos profissionais
"""

import os
import sys
import json
import threading
import subprocess
import traceback
import uuid
from pathlib import Path
from typing import Optional, Dict, List
from datetime import datetime
from dataclasses import dataclass, asdict

# Configurar stdout/stderr
sys.stdout = open(sys.stdout.fileno(), mode='w', encoding='utf-8', buffering=1)
sys.stderr = open(sys.stderr.fileno(), mode='w', encoding='utf-8', buffering=1)

sys.path.insert(0, str(Path(__file__).parent))

print("[TITAN] Iniciando Titan Launcher v2.6.1 ULTIMATE...")

# Importar módulos avançados
try:
    from themes import ThemeManager
    print("[TITAN] Sistema de temas carregado")
except ImportError:
    print("[TITAN] AVISO: módulo themes não encontrado")
    ThemeManager = None

try:
    from notifications import NotificationManager
    print("[TITAN] Sistema de notificações carregado")
except ImportError:
    print("[TITAN] AVISO: módulo notifications não encontrado")
    NotificationManager = None

try:
    from performance import PerformanceMonitor, PerformanceWidget
    print("[TITAN] Monitor de performance carregado")
except ImportError:
    print("[TITAN] AVISO: módulo performance não encontrado")
    PerformanceMonitor = None
    PerformanceWidget = None

try:
    from shader_manager import ShaderManager
    print("[TITAN] Gerenciador de shaders carregado")
except ImportError:
    print("[TITAN] AVISO: módulo shader_manager não encontrado")
    ShaderManager = None

try:
    from profile_manager import ProfileExporter, ProfileBackup
    print("[TITAN] Sistema de exportação/backup carregado")
except ImportError:
    print("[TITAN] AVISO: módulo profile_manager não encontrado")
    ProfileExporter = None
    ProfileBackup = None

try:
    from utils import SystemInfo, QuickActions, ConfigManager
    print("[TITAN] Utilitários carregados")
except ImportError:
    print("[TITAN] AVISO: módulo utils não encontrado")
    SystemInfo = None
    QuickActions = None
    ConfigManager = None

# Importar tkinter
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

print("[TITAN] tkinter carregado")

# Minecraft Launcher Lib
try:
    import minecraft_launcher_lib as mll
    print("[TITAN] minecraft_launcher_lib carregado")
except ImportError:
    print("[TITAN] ERRO CRÍTICO: minecraft_launcher_lib não encontrado!")
    mll = None

# PIL
try:
    from PIL import Image, ImageTk
    print("[TITAN] PIL carregado")
except ImportError:
    Image = None
    ImageTk = None


@dataclass
class GameProfile:
    """Perfil de jogo"""
    id: str
    name: str
    mc_version: str
    mod_loader: str
    loader_version: str
    java_path: str
    ram_gb: int
    username: str
    uuid: str
    game_directory: str
    created_at: str
    mods_directory: Optional[str] = None
    game_directory_custom: Optional[str] = None
    last_played: Optional[str] = None
    installed: bool = False


class ProgressDialog:
    """Janela de progresso para downloads"""
    
    def __init__(self, parent, title="Download em Progresso"):
        self.dialog = tk.Toplevel(parent)
        self.dialog.title(title)
        self.dialog.geometry("500x150")
        self.dialog.transient(parent)
        self.dialog.grab_set()
        self.dialog.configure(bg='#2b2b2b')
        
        # Centralizar
        self.dialog.update_idletasks()
        x = (self.dialog.winfo_screenwidth() // 2) - 250
        y = (self.dialog.winfo_screenheight() // 2) - 75
        self.dialog.geometry(f"+{x}+{y}")
        
        # Label de status
        self.status_label = tk.Label(
            self.dialog,
            text="Preparando...",
            font=("Helvetica", 11),
            bg='#2b2b2b',
            fg='white'
        )
        self.status_label.pack(pady=20)
        
        # Barra de progresso
        self.progress = ttk.Progressbar(
            self.dialog,
            mode='determinate',
            length=450
        )
        self.progress.pack(pady=10)
        
        # Label de detalhes
        self.detail_label = tk.Label(
            self.dialog,
            text="",
            font=("Helvetica", 9),
            bg='#2b2b2b',
            fg='#aaaaaa'
        )
        self.detail_label.pack(pady=5)
        
        self.max_value = 100
        self.current_value = 0
        
    def set_status(self, text):
        self.status_label.config(text=text)
        self.dialog.update()
        
    def set_detail(self, text):
        self.detail_label.config(text=text)
        self.dialog.update()
        
    def set_max(self, value):
        self.max_value = value
        self.progress['maximum'] = value
        
    def set_progress(self, value):
        self.current_value = value
        self.progress['value'] = value
        self.dialog.update()
        
    def close(self):
        self.dialog.destroy()


class TitanLauncher:
    """Launcher principal do Titan"""
    
    def __init__(self):
        print("[TITAN] Inicializando TitanLauncher...")
        
        # Diretórios
        self.config_dir = Path.home() / ".config" / "titanlauncher"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.minecraft_dir = self.config_dir / "minecraft"
        self.minecraft_dir.mkdir(exist_ok=True)
        
        # Configurações
        self.config = self.load_config()
        self.profiles: Dict[str, GameProfile] = {}
        self.load_profiles()
        
        # Versões disponíveis
        self.available_versions = []
        
        # Gerenciadores
        self.theme_manager = ThemeManager() if ThemeManager else None
        self.notification_manager = None
        self.performance_monitor = None
        self.backup_manager = None
        
        if ConfigManager:
            self.config_manager = ConfigManager(self.config_dir / "advanced_config.json")
            if self.theme_manager:
                saved_theme = self.config_manager.get('theme', 'dark')
                self.theme_manager.set_theme(saved_theme)
        else:
            self.config_manager = None
        
        self.root = None
        self.status_label = None
        self.main_frame = None
        
    def create_window(self):
        self.root = tk.Tk()
        self.root.title("Titan Launcher v2.6.1 ULTIMATE")
        self.root.geometry("1100x700")
        self.root.minsize(900, 600)
        
        theme = self.theme_manager.get_theme() if self.theme_manager else {'bg_primary': '#1a1a1a'}
        self.root.configure(bg=theme['bg_primary'])
        
        if NotificationManager:
            self.notification_manager = NotificationManager(self.root)
        
        if PerformanceMonitor:
            self.performance_monitor = PerformanceMonitor(self.root)
            self.performance_monitor.start_monitoring()
        
        if ProfileBackup:
            self.backup_manager = ProfileBackup(self.config_dir / "backups")
        
        self.create_ui()
        
        if self.notification_manager:
            self.notification_manager.show("Bem-vindo!", "Titan Launcher v2.6.1 ULTIMATE carregado!", "success")
        
        if mll:
            threading.Thread(target=self.load_versions, daemon=True).start()
        
    def create_ui(self):
        theme = self.theme_manager.get_theme() if self.theme_manager else {'bg_primary': '#1a1a1a', 'bg_secondary': '#2b2b2b'}
        
        main_container = tk.Frame(self.root, bg=theme['bg_primary'])
        main_container.pack(fill='both', expand=True)
        
        # Header
        header = tk.Frame(main_container, height=70, bg='#0d0d0d')
        header.pack(fill='x', padx=10, pady=5)
        header.pack_propagate(False)
        
        title_label = tk.Label(header, text="TITAN LAUNCHER v2.6.1", font=("Helvetica", 20, "bold"), bg='#0d0d0d', fg='#4a9eff')
        title_label.pack(side='left', padx=10)
        
        # Botão de Configurações (Engrenagem)
        try:
            settings_btn = tk.Button(header, text="⚙", font=("Helvetica", 18), bg='#0d0d0d', fg='white', bd=0, cursor='hand2', command=self.show_settings)
            settings_btn.pack(side='right', padx=15)
        except:
            pass
            
        # Área de conteúdo
        content_frame = tk.Frame(main_container, bg=theme['bg_primary'])
        content_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Sidebar
        sidebar = tk.Frame(content_frame, width=200, bg='#1a1a1a')
        sidebar.pack(side='left', fill='y', padx=(0, 10))
        sidebar.pack_propagate(False)
        
        menu_items = [
            ("Início", self.show_home),
            ("Perfis", self.show_profiles),
            ("Versões", self.show_versions),
            ("Shaders", self.show_shaders),
            ("Backups", self.show_backups),
        ]
        
        for text, command in menu_items:
            btn = tk.Button(sidebar, text=f"  {text}", command=lambda c=command: self._safe_execute(c, text),
                           width=18, bg='#2b2b2b', fg='white', bd=0, padx=15, pady=10, anchor='w', font=("Helvetica", 10), cursor='hand2')
            btn.pack(fill='x', pady=2, padx=5)
            
        # Main Frame
        self.main_frame = tk.Frame(content_frame, bg=theme['bg_secondary'])
        self.main_frame.pack(side='left', fill='both', expand=True)
        
        # Footer
        footer = tk.Frame(main_container, height=40, bg='#0d0d0d')
        footer.pack(fill='x', side='bottom', padx=10, pady=5)
        
        self.status_label = tk.Label(footer, text="Pronto", font=("Helvetica", 9), bg='#0d0d0d', fg='#aaaaaa')
        self.status_label.pack(side='left', padx=10)
        
        if PerformanceWidget and self.performance_monitor:
            perf_widget = PerformanceWidget(footer, self.performance_monitor)
            perf_widget.frame.config(bg='#0d0d0d')
            perf_widget.frame.pack(side='right', padx=10)
            
        self.show_home()

    def _safe_execute(self, command, name):
        try:
            command()
        except Exception as e:
            print(f"[TITAN] Erro em {name}: {e}")
            traceback.print_exc()

    def clear_main_frame(self):
        for widget in self.main_frame.winfo_children():
            widget.destroy()

    def show_home(self):
        self.clear_main_frame()
        theme = self.theme_manager.get_theme() if self.theme_manager else {'bg_secondary': '#2b2b2b'}
        
        container = tk.Frame(self.main_frame, bg=theme['bg_secondary'])
        container.pack(fill='both', expand=True, padx=20, pady=20)
        
        tk.Label(container, text="Bem-vindo ao Titan Launcher v2.6.1", font=("Helvetica", 24, "bold"), bg=theme['bg_secondary'], fg='white').pack(pady=(0, 10))
        tk.Label(container, text="Sua central definitiva de Minecraft no Linux", font=("Helvetica", 12), bg=theme['bg_secondary'], fg='#4caf50').pack(pady=(0, 30))
        
        tk.Button(container, text="+ Criar Novo Perfil", command=self.create_new_profile, bg='#4a9eff', fg='white', font=("Helvetica", 12, "bold"), padx=20, pady=10, bd=0, cursor='hand2').pack(pady=20)
        
        if self.profiles:
            tk.Label(container, text="Perfis Recentes:", font=("Helvetica", 14, "bold"), bg=theme['bg_secondary'], fg='white').pack(anchor='w', pady=(20, 10))
            for pid in list(self.profiles.keys())[:3]:
                self._create_profile_card(container, self.profiles[pid])

    def _create_profile_card(self, parent, profile):
        card = tk.Frame(parent, bg='#353535', padx=15, pady=10)
        card.pack(fill='x', pady=5)
        
        tk.Label(card, text=profile.name, font=("Helvetica", 12, "bold"), bg='#353535', fg='white').pack(side='left')
        tk.Label(card, text=f" ({profile.mc_version})", font=("Helvetica", 10), bg='#353535', fg='#aaaaaa').pack(side='left')
        
        btn_text = "Jogar" if profile.installed else "Instalar"
        btn_bg = '#4caf50' if profile.installed else '#ff9800'
        
        tk.Button(card, text=btn_text, bg=btn_bg, fg='white', bd=0, padx=15, command=lambda p=profile: self.launch_profile(p)).pack(side='right')

    def create_new_profile(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Novo Perfil - Titan Launcher")
        dialog.geometry("500x650")
        dialog.configure(bg='#2b2b2b')
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Centralizar
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - 250
        y = (dialog.winfo_screenheight() // 2) - 325
        dialog.geometry(f"+{x}+{y}")
        
        # Campos
        tk.Label(dialog, text="Nome do Perfil:", bg='#2b2b2b', fg='white').pack(anchor='w', padx=30, pady=(20, 5))
        name_var = tk.StringVar(value="Meu Perfil")
        tk.Entry(dialog, textvariable=name_var, bg='#353535', fg='white', bd=0, font=("Helvetica", 11)).pack(fill='x', padx=30, pady=5)
        
        tk.Label(dialog, text="Versão do Minecraft:", bg='#2b2b2b', fg='white').pack(anchor='w', padx=30, pady=(15, 5))
        version_var = tk.StringVar(value="1.20.1")
        versions = ["1.21.4", "1.21.1", "1.20.1", "1.19.2", "1.18.2", "1.16.5", "1.12.2", "1.8.9"]
        v_menu = ttk.Combobox(dialog, textvariable=version_var, values=versions)
        v_menu.pack(fill='x', padx=30, pady=5)
        
        tk.Label(dialog, text="Mod Loader:", bg='#2b2b2b', fg='white').pack(anchor='w', padx=30, pady=(15, 5))
        loader_var = tk.StringVar(value="vanilla")
        l_menu = ttk.Combobox(dialog, textvariable=loader_var, values=["vanilla", "forge", "fabric"])
        l_menu.pack(fill='x', padx=30, pady=5)
        
        tk.Label(dialog, text="RAM (GB):", bg='#2b2b2b', fg='white').pack(anchor='w', padx=30, pady=(15, 5))
        ram_var = tk.IntVar(value=4)
        tk.Spinbox(dialog, from_=2, to=32, textvariable=ram_var).pack(fill='x', padx=30, pady=5)
        
        # DIRETÓRIO CUSTOMIZADO
        tk.Label(dialog, text="Diretório de Jogo (Onde salvar mods/arquivos):", bg='#2b2b2b', fg='white', font=("Helvetica", 10, "bold")).pack(anchor='w', padx=30, pady=(20, 5))
        dir_var = tk.StringVar(value="")
        dir_frame = tk.Frame(dialog, bg='#2b2b2b')
        dir_frame.pack(fill='x', padx=30, pady=5)
        
        tk.Entry(dir_frame, textvariable=dir_var, bg='#353535', fg='white', bd=0, font=("Helvetica", 9)).pack(side='left', fill='x', expand=True)
        
        def browse():
            path = filedialog.askdirectory()
            if path: dir_var.set(path)
            
        tk.Button(dir_frame, text="Procurar...", command=browse, bg='#454545', fg='white', bd=0).pack(side='right', padx=(5, 0))
        
        def save():
            custom_path = dir_var.get()
            final_dir = custom_path if custom_path else str(self.minecraft_dir / name_var.get())
            
            p = GameProfile(
                id=str(uuid.uuid4())[:8],
                name=name_var.get(),
                mc_version=version_var.get(),
                mod_loader=loader_var.get(),
                loader_version="latest",
                java_path="java",
                ram_gb=ram_var.get(),
                username="Player",
                uuid=str(uuid.uuid4()),
                game_directory=final_dir,
                game_directory_custom=custom_path if custom_path else None,
                created_at=datetime.now().isoformat(),
                installed=False
            )
            self.profiles[p.id] = p
            self.save_profiles()
            dialog.destroy()
            self.show_profiles()
            if self.notification_manager:
                self.notification_manager.show("Sucesso", f"Perfil {p.name} criado!", "success")

        tk.Button(dialog, text="SALVAR PERFIL", command=save, bg='#4a9eff', fg='white', font=("Helvetica", 12, "bold"), pady=10, bd=0).pack(fill='x', padx=30, pady=30)

    def show_profiles(self):
        self.clear_main_frame()
        header = tk.Frame(self.main_frame, bg='#2b2b2b')
        header.pack(fill='x', padx=20, pady=10)
        tk.Label(header, text="Gerenciar Perfis", font=("Helvetica", 20, "bold"), bg='#2b2b2b', fg='white').pack(side='left')
        tk.Button(header, text="+ Novo Perfil", command=self.create_new_profile, bg='#4a9eff', fg='white', bd=0, padx=10).pack(side='right')
        
        container = tk.Frame(self.main_frame, bg='#2b2b2b')
        container.pack(fill='both', expand=True, padx=20)
        
        for pid, p in self.profiles.items():
            card = tk.Frame(container, bg='#353535', pady=10, padx=15)
            card.pack(fill='x', pady=5)
            tk.Label(card, text=p.name, font=("Helvetica", 12, "bold"), bg='#353535', fg='white').pack(side='left')
            tk.Label(card, text=f" [{p.mc_version} - {p.mod_loader}]", bg='#353535', fg='#aaaaaa').pack(side='left')
            
            tk.Button(card, text="Excluir", bg='#f44336', fg='white', bd=0, command=lambda prof=p: self.delete_profile(prof)).pack(side='right', padx=5)
            tk.Button(card, text="Jogar" if p.installed else "Instalar", bg='#4caf50' if p.installed else '#ff9800', fg='white', bd=0, command=lambda prof=p: self.launch_profile(prof)).pack(side='right', padx=5)

    def delete_profile(self, profile):
        if messagebox.askyesno("Confirmar", f"Excluir perfil {profile.name}?"):
            del self.profiles[profile.id]
            self.save_profiles()
            self.show_profiles()

    def show_versions(self):
        self.clear_main_frame()
        tk.Label(self.main_frame, text="Versões Disponíveis", font=("Helvetica", 20, "bold"), bg='#2b2b2b', fg='white').pack(pady=20)
        if not self.available_versions:
            tk.Label(self.main_frame, text="Carregando versões...", bg='#2b2b2b', fg='#aaaaaa').pack()
        else:
            listbox = tk.Listbox(self.main_frame, bg='#353535', fg='white', bd=0)
            listbox.pack(fill='both', expand=True, padx=20, pady=10)
            for v in self.available_versions[:50]:
                listbox.insert(tk.END, f"{v['id']} ({v['type']})")

    def show_shaders(self):
        self.clear_main_frame()
        tk.Label(self.main_frame, text="Gerenciador de Shaders", font=("Helvetica", 20, "bold"), bg='#2b2b2b', fg='white').pack(pady=20)
        tk.Label(self.main_frame, text="Selecione um perfil para gerenciar shaders", bg='#2b2b2b', fg='#aaaaaa').pack()

    def show_backups(self):
        self.clear_main_frame()
        tk.Label(self.main_frame, text="Backups de Perfis", font=("Helvetica", 20, "bold"), bg='#2b2b2b', fg='white').pack(pady=20)
        if self.backup_manager:
            backups = self.backup_manager.list_backups()
            if not backups:
                tk.Label(self.main_frame, text="Nenhum backup encontrado", bg='#2b2b2b', fg='#aaaaaa').pack()
            else:
                for b in backups:
                    tk.Label(self.main_frame, text=f"Backup: {b['name']} ({b['mc_version']})", bg='#2b2b2b', fg='white').pack()

    def show_settings(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Configurações Globais")
        dialog.geometry("400x500")
        dialog.configure(bg='#2b2b2b')
        
        tk.Label(dialog, text="Configurações do Launcher", font=("Helvetica", 16, "bold"), bg='#2b2b2b', fg='white').pack(pady=20)
        
        tk.Label(dialog, text="Tema Visual:", bg='#2b2b2b', fg='white').pack(pady=5)
        if self.theme_manager:
            themes = self.theme_manager.get_all_themes()
            theme_var = tk.StringVar(value=self.theme_manager.current_theme)
            cb = ttk.Combobox(dialog, textvariable=theme_var, values=[t[0] for t in themes])
            cb.pack(pady=5)
            
            def apply():
                self.theme_manager.set_theme(theme_var.get())
                messagebox.showinfo("Tema", "Tema aplicado! Reinicie para efeito total.")
            
            tk.Button(dialog, text="Aplicar Tema", command=apply).pack(pady=10)

    def launch_profile(self, profile):
        if not profile.installed:
            self.install_minecraft(profile)
        else:
            self.run_minecraft(profile)

    def install_minecraft(self, profile):
        progress = ProgressDialog(self.root, f"Instalando {profile.name}")
        def do_install():
            try:
                path = Path(profile.game_directory)
                path.mkdir(parents=True, exist_ok=True)
                mll.install.install_minecraft_version(profile.mc_version, str(path), callback={'setMax': progress.set_max, 'setProgress': progress.set_progress})
                profile.installed = True
                self.save_profiles()
                progress.close()
                self.root.after(0, lambda: messagebox.showinfo("Sucesso", "Instalação concluída!"))
                self.root.after(0, self.show_profiles)
            except Exception as e:
                progress.close()
                self.root.after(0, lambda: messagebox.showerror("Erro", str(e)))
        threading.Thread(target=do_install, daemon=True).start()

    def run_minecraft(self, profile):
        try:
            options = {'username': profile.username, 'uuid': profile.uuid, 'token': '', 'jvmArguments': [f"-Xmx{profile.ram_gb}G"], 'gameDirectory': profile.game_directory}
            command = mll.command.get_minecraft_command(profile.mc_version, profile.game_directory, options)
            subprocess.Popen(command)
            if self.notification_manager:
                self.notification_manager.show("Iniciando", f"Abrindo {profile.name}...", "info")
        except Exception as e:
            messagebox.showerror("Erro", str(e))

    def load_versions(self):
        try:
            self.available_versions = mll.utils.get_version_list()
        except: pass

    def load_config(self):
        path = self.config_dir / "launcher_config.json"
        if path.exists():
            with open(path, 'r') as f: return json.load(f)
        return {}

    def load_profiles(self):
        path = self.config_dir / "profiles.json"
        if path.exists():
            try:
                with open(path, 'r') as f:
                    data = json.load(f)
                    for pid, pdata in data.items():
                        self.profiles[pid] = GameProfile(**pdata)
            except: pass

    def save_profiles(self):
        path = self.config_dir / "profiles.json"
        with open(path, 'w') as f:
            json.dump({pid: asdict(p) for pid, p in self.profiles.items()}, f, indent=2)

    def run(self):
        self.create_window()
        self.root.mainloop()


if __name__ == "__main__":
    launcher = TitanLauncher()
    launcher.run()
